#include-once

#cs ----------------------------------------------------------------------------

     AutoIt Version: 3.3.18.0
     Author:         Coaxx/Incognito update 5/31/26

     Script Function:
        Farmer Hamnet - Pre Searing

#ce ----------------------------------------------------------------------------

Global Const $HAMNET_MAP_ID = 165   ; Foible's Fair

Global $HamnetPath[5][2] = [ _
    [2029, 6454], _
    [2440, 5035], _
    [2615, 4486], _
    [2292, 4856], _
    [2377, 5398] _
]

Global $HamnetLeavePath[3][2] = [ _
    [93, 8574], _
    [357, 7858], _
    [633, 7270] _
]

Global $currLevel = 0
Global $oldLevel = 0
Global $HamnetState

Func Farm_Hamnet()
    While 1
        If CountSlots() < 4 Then InventoryPre()
        If Not $hasBonus Then GetBonus()

        HamnetSetup()

        While CountSlotS() > 1
            If Not $BotRunning Then
                ResetStart()
                Return
            EndIf

            Hamnet()
        WEnd
    WEnd
EndFunc

Func HamnetSetup()
    If Map_GetMapID() = $HAMNET_MAP_ID Then
        LogInfo("We are in Foible's Fair. Starting the bandit farm...")
    ElseIf Map_GetMapID() <> $HAMNET_MAP_ID And Map_IsMapUnlocked($HAMNET_MAP_ID) Then
        LogInfo("We are not in Foible's Fair. Teleporting to Foible's Fair...")
        Map_RndTravel($HAMNET_MAP_ID)
        Sleep(2000)
    ElseIf Not Map_IsMapUnlocked($HAMNET_MAP_ID) Then
        LogWarn("Foible's Fair is not unlocked on this character, lets try to run there...")
        While Not UnlockFoibles()
            LogError("Failed to unlock Foible's Fair.  Retrying...")
            Sleep(2000)
        WEnd
    EndIf

    QuestActive(0x4A1)
    Sleep(750)
    $HamnetState = Quest_GetQuestInfo(0x4A1, "LogState")

    If $HamnetState = 1 Then
        LogInfo("Lets kill some Banditos!")
    ElseIf $HamnetState = 0 Then
        LogInfo("We don't have the Hamnet quest!")
        LogWarn("Check to see when it's next available.")
        LogStatus("Bot will now pause...")
        $BotRunning = False
        Return
    ElseIf $HamnetState = 3 Then
        LogInfo("Hamnet quest is completed!")
        LogError("Cannot proceed with the farm.")
        LogStatus("Bot will now pause...")
        $BotRunning = False
        Return
    EndIf

    Sleep(1000)
EndFunc

Func HamnetLeaveOutpost()
    RunTo($HamnetLeavePath)
    Sleep(1650)
    MoveTo(709, 7115)
    UseSummoningStone()
EndFunc

Func HamnetMapToOutpost()
    Map_RndTravel($HAMNET_MAP_ID)
    Map_WaitMapLoading($HAMNET_MAP_ID, 0)
    Sleep(1000)
EndFunc

Func Hamnet()
    $currLevel = Agent_GetAgentInfo(-2, "Level")

    If $_19Stop And $currLevel >= 19 Then
        LogWarn("Reached level 19, stopping the farm.")
        LogStatus("Bot will now pause.")
        $BotRunning = False
        Return
    EndIf

    If $currLevel > $oldLevel Then
        LogWarn("You are now level " & $currLevel & "!")
        Sleep(750)
        $oldLevel = $currLevel
    EndIf

    HamnetLeaveOutpost()

    $RunTime = TimerInit()

    RunTo($HamnetPath)
    AggroMoveSmartFilter(2574, 5885, 2200, 2200, $BanditFilter, True)

    If SurvivorMode() Then
        LogError("Survivor activated. Map_RndTravel(" & $HAMNET_MAP_ID & ")")
        UpdateStats()
        HamnetMapToOutpost()
        Return
    EndIf

    LogInfo("Run complete. Restarting...")
    UpdateStats()
    Sleep(250)
    HamnetMapToOutpost()
EndFunc
