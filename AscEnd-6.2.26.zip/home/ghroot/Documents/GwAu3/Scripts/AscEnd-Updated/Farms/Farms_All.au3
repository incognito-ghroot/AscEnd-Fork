#include-once
#include "Farm_RedIris.au3"
#include "Farm_CharrBossFarmLoop.au3"
#include "Farm_UnnaturalSeeds.au3"
#include "Farm_CharrAtTheGate.au3"
#include "Farm_Hamnet.au3"
#include "Farm_RunToOutposts.au3"
#include "Farm_WornBelts.au3"
#include "Farm_CharrBossFarm.au3"
#include "Farm_GargoyleSkull.au3"
#include "Farm_EnchLodes.au3"
#include "Farm_IcyLodes.au3"
#include "Farm_BakedHusk.au3"
#include "Farm_Skeletons.au3"
#include "Farm_Skale.au3"
#include "Farm_Carapace.au3"
#include "Farm_GrawlNecklace.au3"
#include "Farm_NickExchange.au3"
#include "Farm_NickFarm_Exchange.au3"
#include "Farm_SkaleAlt.au3"

Global $g_a_Farms[20][2] = [ _
    ["", ""], _
    ["Red Iris Run", "Farm_RedIris"], _
	["Charr Boss Farm Loop", "Farm_CharrBossFarmLoop"], _
    ["Farmer Hamnet", "Farm_Hamnet"], _
	["Charr at the Gate", "Farm_CharrAtTheGate"], _
	["Run To Outposts", "Farm_RunToOutposts"], _
    ["Unnatural Seeds", "Farm_UnnaturalSeeds"], _
    ["Worn Belts", "Farm_WornBelts"], _
    ["Gargoyle Skulls", "Farm_GargoyleSkull"], _
    ["Enchanted Lodes", "Farm_EnchLodes"], _
    ["Icy Lodes", "Farm_IcyLodes"], _
    ["Baked Husks", "Farm_BakedHusk"], _
    ["Skeleton Limbs", "Farm_SkeletonLimbs"], _
    ["Skale Fins", "Farm_Skale"], _
    ["Skale Fins Alt", "Farm_SkaleAlt"], _
    ["Dull Carapace", "Farm_Carapace"], _
    ["Grawl Necklace", "Farm_GrawlNecklace"], _
    ["Nick Exchange", "Farm_NickExchange"], _
	["Charr Boss Farm", "Farm_CharrBossFarm"], _
    ["Nick Farm & Exchange", "Farm_NickFarm"] _
]