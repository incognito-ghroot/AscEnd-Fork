#include-once

#cs ----------------------------------------------------------------------------

     AutoIt Version: 3.3.18.0
     Author:         Incognito

     Script Function:
        Worn Belts Farm - Pre Searing

#ce ----------------------------------------------------------------------------

Global $BeltFarmPath[6][2] = [ _
    [-9410, -6145], _
    [-8250, -5525], _
    [-7251, -4203], _
    [-6897, -3153], _
    [-5660, -3164], _
    [-6593, -2865] _
]

Global $BeltFarmBattle[3][2] = [ _
    [-6338, -2849], _
    [-6124, -2085], _
    [-6314, -1282] _
]

Global $BeltFarmState

Func Farm_WornBelts()
    While 1
        If CountSlots() < 4 Then InventoryPre()
        If Not $hasBonus Then GetBonus()

        WornBeltsSetup()

        While CountSlots() > 1
            If Not $BotRunning Then
                ResetStart()
                Return
            EndIf

            If $NickRun Then
                Local $currentCount = GetItemCountByModelID($NickItem[0])
                If $currentCount >= 25 Then
                    LogInfo("Nicholas farm goal reached! Collected " & $currentCount & " " & $NickItem[1])
                    Return
                EndIf
            EndIf

            WornBeltsFarm()
        WEnd
    WEnd
EndFunc

Func WornBeltsSetup()
    QuestActive(0x29)
    Sleep(250)
    $BeltFarmState = Quest_GetQuestInfo(0x29, "LogState")

    If $BeltFarmState = 1 Then
        LogInfo("Lets kill some Belt Thieves!")
    ElseIf $BeltFarmState = 0 Then
        LogError("We don't have the Bandit Raid quest!")
        LogInfo("Lets get it!")
        Sleep(1000)
        If Not GetBeltQuest() Then Return
    ElseIf $BeltFarmState = 3 Then
        LogWarn("Bandit Raid quest is completed, lets ditch and retake it!")
        Quest_AbandonQuest(0x29)
        Sleep(1000)
        If Not GetBeltQuest() Then Return
    EndIf

    If Map_GetMapID() = 164 Then
        LogInfo("We are in Ashford Abbey. Starting Worn Belts Farm...")
    ElseIf Map_GetMapID() <> 164 And Map_IsMapUnlocked(164) Then
        LogInfo("We are not in Ashford Abbey. Teleporting to Ashford...")
        Map_RndTravel(164)
        Sleep(2000)
    ElseIf Not Map_IsMapUnlocked(164) Then
        LogWarn("Ashford Abbey is not unlocked on this character, lets try to run there...")
        While Not UnlockAshford()
            LogError("Failed to unlock Ashford Abbey.  Retrying...")
            Sleep(2000)
        WEnd
    EndIf

    ExitAshford() ; Gate trick setup
    Map_Move(-11100, -6200)
    Map_WaitMapLoading(164, 0)
    Sleep(2000)
EndFunc

Func WornBeltsFarm()
    Map_Move(-11089, -6250) ; Leave Ashford Abbey
    Map_WaitMapLoading(146, 1)

    Sleep(1000)

    $RunTime = TimerInit()

    RunTo($BeltFarmPath)
    UseSummoningStone()
    RunToWB($BeltFarmBattle)
    Other_RndSleep(250)
    LogInfo("Worn Belts Farm complete. Restarting...")
    If SurvivorReturnToOutpost() Then Return
    UpdateStats()
    Other_RndSleep(250)
    Map_ReturnToOutpost()
EndFunc

Func RunToWB($g_a_RunPath)
    For $i = 0 To UBound($g_a_RunPath) - 1
        AggroMoveSmartFilter($g_a_RunPath[$i][0], $g_a_RunPath[$i][1], 2200, 2200, $BanditFilter, True, 2500)
        If SurvivorMode() Then Return
    Next
EndFunc

Func GetBeltQuest()
    $spawn[0] = Agent_GetAgentInfo(-2, "X")
    $spawn[1] = Agent_GetAgentInfo(-2, "Y")
    Local $sp1 = ComputeDistance(11062, 10709, $spawn[0], $spawn[1])

    If $sp1 < 3500 Then
        LogInfo("Come here you boring ass!")
        MoveTo(11022, 9397)
    ElseIf $sp1 >= 3500 Then
        LogInfo("All these stairs..")
        MoveTo(8232, 6228)
        MoveTo(11126, 9194)
    EndIf

    MoveTo(11062, 10709)

    Other_RndSleep(1000)
    Agent_GoNPC(GetNearestNPCToAgent(-2))
    Other_RndSleep(500)
    Ui_Dialog(0x802903)
    Other_RndSleep(500)
    Ui_Dialog(0x802901)

    Sleep(1000)

    QuestActive(0x29)
    Sleep(250)
    $BeltFarmState = Quest_GetQuestInfo(0x29, "LogState")

    If $BeltFarmState = 1 Then
        LogWarn("Bandit Raid quest is active!")
        Return True
    Else
        LogError("Cannot take quest!")
        LogStatus("Bot will now pause...")
        $BotRunning = False
        Return False
    EndIf
EndFunc