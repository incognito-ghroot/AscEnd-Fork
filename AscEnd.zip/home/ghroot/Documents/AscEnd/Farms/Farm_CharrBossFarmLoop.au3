#include-once

#cs ----------------------------------------------------------------------------

     AutoIt Version: 3.3.18.0
     Author:         Incognito/Coaxx

     Script Function:
        Charr Boss Farm Loop - Pre Searing

#ce ----------------------------------------------------------------------------

Global $NormalGatePathLoop[3][2] = [[-12398, -13343], [-12996, -11276], [-11087, -8753]]

Global $CharrGatePathLoop[4][2] = [[3118, 6530], [36, 6952], [-3215, 12159], [-5413, 12808]]

Global $retrypathLoop[5][2] = [[-5321, 11802], [-3690, 11398], [-3296, 11764], [-3663, 12426], [-5408, 12806]]

Global $CharrPortalPathLoop[5][2] = [[-3925, 12379], [-3760, 11583], [-5409, 11872], [-5497, 13166], [-5572.39, 14130.93]]

Global $RunBackPath[6][2] = [[640.81, -3235.88], [-8671.25, -5970.66], [-11825.55, -8061.91], [-13122.18, -10097.40], [-12564.54, -12897.19], [-12626, -12638]]

Func Farm_CharrBossFarmLoop()

    $CharrBossFarm = True ; Set this to 'True' if you only want to farm charr bosses, if 'False' will pickup all collectibles.
    InitialSetup()

    While 1
        If CountSlots() < 4 Then InventoryPre()
        If Not $hasBonus Then GetBonus()

        While CountSlots() > 1
            If Not $BotRunning Then
                ResetStart()
                Return
            EndIf

            If Map_GetMapID() <> 148 Then
                Map_RndTravel(148)
            EndIf

            RunToGate()

            While True
                If Not CharrCombatLoop() Then ExitLoop
            WEnd
        WEnd
    WEnd
EndFunc

Func RunToGate() ; Exit and run to the charr gate
    ExitAscalon()
    LogInfo("Running to the Charr Gate...")
    RunTo($CharrGatePathLoop)
    Sleep(1000)
EndFunc

Func OpenGate() ; Pull lever until we get to the Northlands

    If Map_GetMapID() <> 146 Then Return ; Keep track of where we are - Failsafe(Should be in Lakeside Country)

    Do
        LogInfo("Opening the gate lever...")
        Agent_GoSignpost(GetNearestGadgetToAgent(-2))
        Sleep(250)

        LogInfo("Moving to the Charr portal...")
        RunTo($CharrPortalPathLoop)
        Map_InitMapIsLoaded()
        Map_Move(-5598, 14178)
        Map_WaitMapIsLoaded()

        If Map_GetMapID() <> 147 Then
            LogError("Failed to arrive in the Northlands...")
            Sleep(1000)
            LogWarn("Retrying the lever...")
            RunTo($retrypathLoop)
        EndIf
    Until Map_GetMapID() = 147

EndFunc

Func CharrCombatLoop() ; Combat loop for charr bosses
    OpenGate()

    If Map_GetMapID() <> 147 Then Return False ; Keep track of where we are - Failsafe(Should be in the Northlands)

    LogInfo("Arrived in the Northlands, time to burn some furr.")

    $RunTime = TimerInit()

    UseSummoningStone()
    RunToUpkeep($NormalGatePathLoop, $gUpkeepSkills)

    Switch $gProf
        Case 63
            If Not GetPartyDead() Then FirstGroupEmo()
            If Not GetPartyDead() Then GrawlEmo() ; Fight Grawl if they are there?
            If Not GetPartyDead() Then SecondGroupEmo()
            If Not GetPartyDead() Then LeftCornerEmo()
            If Not GetPartyDead() Then BossesEmo()
        Case 42
            If Not GetPartyDead() Then FirstGroupNecro()
            If Not GetPartyDead() Then GrawlNecro()
            If Not GetPartyDead() Then SecondGroupNecro()
            If Not GetPartyDead() Then LeftCornerNecro()
            If Not GetPartyDead() Then BossesNecro()
    EndSwitch

    If SurvivorReturnToOutpost() Then Return False

    If GetPartyDead() Then
        LogWarn("You died because you couldn't fight your way out of a paper bag...")
        LogInfo("Returning to Ascalon...")
        UpdateStats()
        Other_RndSleep(250)
        Map_ReturnToOutpost()
        Return False
    EndIf

    LogInfo("Run complete. Running back to portal...")
    UpdateStats()

    Other_RndSleep(250)

    If Not RunBackToPortal() Then
        LogWarn("Failed to make it to the portal...")
        LogInfo("Returning to Ascalon...")
        Return False
    EndIf

    Return True
EndFunc

Func FirstGroup()
    LogInfo("Clearing first group of charr...")

    MoveUpkeepEx(-10998, -7203, $gUpkeepSkills)

    Local $target = GetNearestCharrToAgent(-2)

    Agent_Attack($target)

    If StayAlive_Kill(-10510.99, -6543.00,"CharrFilter", 2000) Then
        LogInfo("First group of charr cleared.")
        Sleep(250)
        LogInfo("Picking up loot...")
        Sleep(250)
        PickUpLootInRange(2000)
    EndIf

    If GetPartyDead() Then Return False
EndFunc

Func Grawl()
    MoveUpkeepEx(-55949, -4163, $gUpkeepSkills)
    LogInfo("Checking for grawl...")
    Local $timer = TimerInit()

    Do
        StayAlive()
        If GetPartyDead() Then Return False
        Sleep(100)
    Until GetNumberOfFoesInRangeOfAgent(-2, 1600) > 0 _
        Or TimerDiff($timer) > 5000

    ; Skip if nothing is there
    If GetNumberOfFoesInRangeOfAgent(-2, 1600) = 0 Then
        LogInfo("No grawl found, moving on.")
        Return True
    EndIf

    LogInfo("Taking out the trash...")
    If StayAlive_Kill(-5271.52, -4490.23, "EnemyFilter", 1500) Then
        LogInfo("Grawl cleared.")
    EndIf
    If GetPartyDead() Then Return False
    Return True
EndFunc

Func SecondGroup()
    LogInfo("Clearing second group of charr...")

    MoveUpkeepEx(-2558.01, -3666.43, $gUpkeepSkills)
    If GetPartyDead() Then Return False

    Local $target = GetNearestCharrToAgent(-2)
    If $target <> 0 Then Agent_Attack($target)

    If StayAlive_Kill(-2558.01, -3666.43, "CharrFilter", 2000) Then
        LogInfo("First group of charr cleared.")
        LogInfo("Checking for nearby foes...")
    EndIf
    If GetPartyDead() Then Return False
    Return True
EndFunc

Func LeftCorner()
    Local $BossLeftCorner = 1452
    Local $timer

    ; First standing/wait spot
    MoveUpkeepEx(-381, -2202, $gUpkeepSkills)

    $timer = TimerInit()

    LogInfo("Waiting for left corner group...")
    Do
        StayAlive()
    Until GetNumberOfCharrInRangeOfAgent(-2, 1500) > 2 _
        Or GetPartyDead() _
        Or TimerDiff($timer) > $enemyKillTime

    If GetPartyDead() Then Return False

    Local $target = GetNearestCharrToAgent(-2)

    If $target <> 0 Then
        Agent_Attack($target)
        Sleep(500)
    EndIf

    ; Move-back safety spot
    MoveUpkeepEx(316, -2627, $gUpkeepSkills)

    If $target <> 0 Then Agent_Attack($target)

    LogInfo("Clearing left corner ele boss group...")

    ; First kill spot
    If StayAlive_Kill(316, -2627, "CharrFilter", 2450) Then
        LogInfo("Left corner first kill spot cleared.")
    EndIf

    If GetPartyDead() Then Return False

    ; Second kill spot
    MoveUpkeepEx(614, -2627, $gUpkeepSkills)

    If StayAlive_Kill(614, -2627, "CharrFilter", 2400) Then
        LogInfo("Left corner ele boss cleared.")
    EndIf

    If GetPartyDead() Then Return False

    LogInfo("Picking up left corner ele boss loot...")
    PickUpLootInRange(3700, 614, -2627)

    Return True
EndFunc


Func Bosses()
    Local $BossKills = 1451, 1453, 1450

    LogInfo("Clearing remaining boss group...")

    ; Kill spot 1
    MoveUpkeepEx(1276, -2344, $gUpkeepSkills)

    If StayAlive_Kill(1276, -2344, "CharrFilter", 3700) Then
        LogInfo("Boss kill spot 1 cleared.")
    EndIf

    If GetPartyDead() Then Return False

    Sleep(750)

    ; Kill spot 2
    MoveUpkeepEx(1276, -2344, $gUpkeepSkills)

    If StayAlive_Kill(1276, -2344, "CharrFilter", 3700) Then
        LogInfo("Boss kill spot 2 cleared.")
    EndIf

    If GetPartyDead() Then Return False

    Sleep(1000)

    LogInfo("Picking up remaining boss loot...")

    ; Loot after both boss spots are clear
    PickUpLootInRange(4800, 1276, -2344)

    If GetPartyDead() Then Return False

    LogInfo("Bosses complete.")
    Return True
EndFunc

Func RunBackToPortal()
    RunToUpkeep($RunBackPath, $gUpkeepSkills)

    If GetPartyDead() Then
        LogWarn("Died on our way to the portal...")
        Return False
    EndIf

    Map_InitMapIsLoaded()
    Map_Move(-11652, -16955)
    Map_WaitMapIsLoaded()
    Sleep(500)

    If Map_GetMapID() = 146 Then
        LogWarn("Returned to Lakeside County. Retrying the lever...")
        RunTo($retrypathLoop)
        Return True
    EndIf

    Return False
EndFunc